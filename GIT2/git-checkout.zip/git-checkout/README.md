General
=======

- Clone this repo
- Checkout repo's history
- Find 3d commit from the start
- Checkout to it
- Send me a message with deleted.txt content

Telegram
========
- Let's keep in touch! @drunkdevops
