General
=======

This repo contains 3 branches:
- master
- develop
- staging

You need to merge staging branch into develop and then into master. Be ready to fix merge conflicts if needed. Keep latest (by date) changes when merging.
