Squash
=======

Simple repo to show how rebase works
We have 2 branches here:
- master
- develop

You can find a lot of similar commits in develop branch. You have to squash them into 1 single commit.
