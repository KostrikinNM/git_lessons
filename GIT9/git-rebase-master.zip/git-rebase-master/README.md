Rebase
=======

Simple repo to show how rebase works
We have 3 branches here:
- master
- develop
- feature

Check `git log` for commits we have and then rebase feature branch into develop and then into master).
