Cherry Pick
=======

Simple repo to show how cherry-pick works
We have 2 branches here:
- master
- develop

develop branch contains 3 different commits:
- function rename
- code formatting
- simplifiying sum function

You have to cherry-pick second commit (code formatting) and apply it to master branch. 
